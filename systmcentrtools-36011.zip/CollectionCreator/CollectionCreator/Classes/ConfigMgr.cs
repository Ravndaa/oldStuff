﻿using Microsoft.ConfigurationManagement.ManagementProvider;
using Microsoft.ConfigurationManagement.ManagementProvider.WqlQueryEngine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionCreator.Classes
{
    public class ConfigMgr
    {

        public WqlConnectionManager connect(string server, string username, string password)
        {
            
                SmsNamedValuesDictionary namedValues = new SmsNamedValuesDictionary();
                WqlConnectionManager connection = new WqlConnectionManager(namedValues);

                if (string.IsNullOrEmpty(username) == true || string.IsNullOrEmpty(password) == true)
                {
                    connection.Connect(server);
                }
                else
                {
                    connection.Connect(server, username, password);
                }

                return connection;

        }


        public IResultObject CreateRecurringScheduleToken(WqlConnectionManager connection, int hourDuration, int daySpan, string startTime, bool isGmt, int dayDuration, int minuteDuration, int hourSpan, int minuteSpan)
        {
            
                // Create a new recurring interval schedule object.
                // Note: There are several types of schedule classes available, each defines a different type of schedule.
                IResultObject recurInterval = connection.CreateEmbeddedObjectInstance("SMS_ST_RecurInterval");
                // Populate the schedule properties.
                recurInterval["DayDuration"].IntegerValue = dayDuration;
                recurInterval["HourDuration"].IntegerValue = hourDuration;
                recurInterval["MinuteDuration"].IntegerValue = minuteDuration;
                recurInterval["DaySpan"].IntegerValue = daySpan;
                recurInterval["HourSpan"].IntegerValue = hourSpan;
                recurInterval["MinuteSpan"].IntegerValue = minuteSpan;
                recurInterval["StartTime"].StringValue = startTime;
                recurInterval["IsGMT"].BooleanValue = isGmt;
                return recurInterval;
            
        }


    }
}
