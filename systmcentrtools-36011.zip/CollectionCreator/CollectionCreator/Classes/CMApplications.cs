﻿using CollectionCreator.Helpers;
using Microsoft.ConfigurationManagement.ManagementProvider;
using Microsoft.ConfigurationManagement.ManagementProvider.WqlQueryEngine;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionCreator.Classes
{
    public class CMApplications : ObservableObject
    {

        private string _Name;
        private string _Version;
        private string _Type;
        private string _ProductCode;

        public string Name
        {
            get { return this._Name; }
            set
            {
                if (this._Name != value)
                {
                    this._Name = value;
                    NotifyPropertyChanged(() => this.Name);
                }
            }
        }

        public string Version
        {
            get { return this._Version; }
            set
            {
                if (this._Version != value)
                {
                    this._Version = value;
                    NotifyPropertyChanged(() => this.Version);
                }
            }
        }

        public string Type
        {
            get { return this._Type; }
            set
            {
                if (this._Type != value)
                {
                    this._Type = value;
                    NotifyPropertyChanged(() => this.Type);
                }
            }
        }

        public string ProductCode
        {
            get { return this._ProductCode; }
            set
            {
                if (this._ProductCode != value)
                {
                    this._ProductCode = value;
                    NotifyPropertyChanged(() => this.ProductCode);
                }
            }
        }




        public ObservableCollection<CMApplications> GetAll(WqlConnectionManager WMIConnection, string search = null)
        {

                //Variables
                string query32 = "";
                string query64 = "";

                //This will contain all applications found in CM
                var items = new ObservableCollection<CMApplications>();

                if (String.IsNullOrWhiteSpace(search))
                {
                    query32 = "SELECT DISTINCT DisplayName,Version,ProdID FROM SMS_G_SYSTEM_ADD_REMOVE_PROGRAMS";
                    query64 = "SELECT DISTINCT DisplayName,Version,ProdID FROM SMS_G_SYSTEM_ADD_REMOVE_PROGRAMS_64";
                }
                else
                {

                    query32 = "SELECT DISTINCT DisplayName,Version,ProdID FROM SMS_G_SYSTEM_ADD_REMOVE_PROGRAMS WHERE DisplayName LIKE \"%" + search + "%\"";
                    query64 = "SELECT DISTINCT DisplayName,Version,ProdID FROM SMS_G_SYSTEM_ADD_REMOVE_PROGRAMS_64 WHERE DisplayName LIKE \"%" + search + "%\"";
                }

                IResultObject Apps32 = WMIConnection.QueryProcessor.ExecuteQuery(query32);
                IResultObject Apps64 = WMIConnection.QueryProcessor.ExecuteQuery(query64);

                foreach (IResultObject app32 in Apps32)
                {
                    //MessageBox.Show(app32["DisplayName"].StringValue);
                    items.Add(new CMApplications { Name = app32["DisplayName"].StringValue, Version = app32["Version"].StringValue, ProductCode = app32["ProdID"].StringValue, Type = "32" });
                }
                foreach (IResultObject app64 in Apps64)
                {
                    //MessageBox.Show(app32["DisplayName"].StringValue);
                    items.Add(new CMApplications { Name = app64["DisplayName"].StringValue, Version = app64["Version"].StringValue, ProductCode = app64["ProdID"].StringValue, Type = "64" });
                }

                return items;

        }

    
    }
}
