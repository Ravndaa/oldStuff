﻿using CollectionCreator.Helpers;
using Microsoft.ConfigurationManagement.ManagementProvider;
using Microsoft.ConfigurationManagement.ManagementProvider.WqlQueryEngine;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionCreator.Classes
{
    public class CMGroups : ObservableObject
    {

        private string _Group;

        public string Group
        {
            get { return this._Group; }
            set
            {
                if (this._Group != value)
                {
                    this._Group = value;
                    NotifyPropertyChanged(() => this.Group);
                }
            }
        }



        public ObservableCollection<CMGroups> Get(WqlConnectionManager WMIConnection, string search = null)
        {


            var items = new ObservableCollection<CMGroups>();
            string query = "SELECT Name FROM SMS_R_UserGroup WHERE Name LIKE '" +search + "%'";
               

            IResultObject Collections = WMIConnection.QueryProcessor.ExecuteQuery(query);

            foreach (IResultObject Col in Collections)
            {
                items.Add(new CMGroups { Group = Col["Name"].StringValue});
            }


            return items;

        }


    }
}
