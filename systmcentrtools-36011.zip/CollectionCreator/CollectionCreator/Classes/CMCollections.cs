﻿using CollectionCreator.Helpers;
using Microsoft.ConfigurationManagement.ManagementProvider;
using Microsoft.ConfigurationManagement.ManagementProvider.WqlQueryEngine;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionCreator.Classes
{
    public class CMCollections : ObservableObject
    {

        private string _Name;
        private string _Id;
        private string _Type;

        public string Name
        {
            get { return this._Name; }
            set
            {
                if (this._Name != value)
                {
                    this._Name = value;
                    NotifyPropertyChanged(() => this.Name);
                }
            }
        }

        public string Id
        {
            get { return this._Id; }
            set
            {
                if (this._Id != value)
                {
                    this._Id = value;
                    NotifyPropertyChanged(() => this.Id);
                }
            }
        }

        public string Type
        {
            get { return this._Type; }
            set
            {
                if (this._Type != value)
                {
                    this._Type = value;
                    NotifyPropertyChanged(() => this.Type);
                }
            }
        }



        public ObservableCollection<CMCollections> Get(WqlConnectionManager WMIConnection, string search = null, string type = null)
        {


                var items = new ObservableCollection<CMCollections>();
                string query;


                if (type == null)
                {

                    if (search == null)
                    {
                        query = "SELECT CollectionID,CollectionType,Name FROM SMS_Collection WHERE CollectionType = 1 OR CollectionType = 2";
                    }
                    else
                    {
                        query = "SELECT CollectionID,CollectionType,Name FROM SMS_Collection WHERE (CollectionType = 1 OR CollectionType = 2) AND Name LIKE \"%" + search + "%\"";
                    }
                }
                else
                {

                    if (search == null)
                    {
                        query = "SELECT CollectionID,CollectionType,Name FROM SMS_Collection WHERE CollectionType= \"" + type + "\"";
                    }
                    else
                    {
                        query = "SELECT CollectionID,CollectionType,Name FROM SMS_Collection WHERE CollectionType= \"" + type + "\" AND Name LIKE \"%" + search + "%\"";
                    }
                }

                IResultObject Collections = WMIConnection.QueryProcessor.ExecuteQuery(query);

                foreach (IResultObject Col in Collections)
                {
                    items.Add(new CMCollections { Name = Col["Name"].StringValue, Id = Col["CollectionID"].StringValue, Type = Col["CollectionType"].StringValue });
                }

               
                return items;

        }


        public IResultObject Create(WqlConnectionManager WMIConnection, string newCollectionName, string newCollectionComment, bool ownedByThisSite, string LimitToCollectionID, int colType, int refreshType)
        {
                 // Create new SMS_Collection object.        
                IResultObject newCollection = WMIConnection.CreateInstance("SMS_Collection");
                // Populate the new collection object properties.        
                newCollection["Name"].StringValue = newCollectionName;
                newCollection["Comment"].StringValue = newCollectionComment;
                newCollection["OwnedByThisSite"].BooleanValue = ownedByThisSite;
                newCollection["LimitToCollectionID"].StringValue = LimitToCollectionID;
                newCollection["CollectionType"].IntegerValue = colType;
                newCollection["RefreshType"].IntegerValue = refreshType;
                // Save the new collection object and properties.        
                // In this case, it seems necessary to 'get' the object again to access the properties.        
                newCollection.Put();
                newCollection.Get();

                return newCollection;
            

        }


        public void AddQuery(WqlConnectionManager WMIConnection, IResultObject newCollection, string query, string ruleName)
        {

                // Validate the query.        
                Dictionary<string, object> validateQueryParameters = new Dictionary<string, object>();
                validateQueryParameters.Add("WQLQuery", query);
                IResultObject result = WMIConnection.ExecuteMethod("SMS_CollectionRuleQuery", "ValidateQuery", validateQueryParameters);
                // Create query rule.        
                IResultObject newQueryRule = WMIConnection.CreateInstance("SMS_CollectionRuleQuery");
                newQueryRule["QueryExpression"].StringValue = query;
                newQueryRule["RuleName"].StringValue = ruleName;
                // Add the rule. Although not used in this sample, QueryID contains the query identifier.                           
                Dictionary<string, object> addMembershipRuleParameters = new Dictionary<string, object>();
                addMembershipRuleParameters.Add("collectionRule", newQueryRule);
                IResultObject queryID = newCollection.ExecuteMethod("AddMembershipRule", addMembershipRuleParameters);
                // Start collection evaluator.        
                newCollection.ExecuteMethod("RequestRefresh", null);

        }


    }
}
