﻿using Microsoft.EnterpriseManagement.Configuration;
using Microsoft.EnterpriseManagement.Configuration.IO;
using Microsoft.EnterpriseManagement.Packaging;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace MPExtractor.Classes
{
    public class MonitoringPacks : ObservableObject
    {

        private string _path;
        
        public string Path
        {
            get { return this._path; }
            set
            {
                if (this._path != value)
                {
                    this._path = value;
                    NotifyPropertyChanged(() => this.Path);
                }
            }
        }


        public void ExtractMP(string inpath, string outpath)
        {

            ManagementPack file = new ManagementPack(inpath);
            Directory.CreateDirectory(outpath + @"\" + file.Name);
            ManagementPackXmlWriter mpwrite = new ManagementPackXmlWriter(outpath + @"\" + file.Name);

            mpwrite.WriteManagementPack(file);

        }

        

        public void ExtractMPB(string inpath, string outpath)
        {
            String[] path = new String[] { inpath };
            ManagementPackFileStore mpStore = new ManagementPackFileStore(path);

            ManagementPackBundleReader mpbReader = ManagementPackBundleFactory.CreateBundleReader();

            ManagementPackXmlWriter mpWrite = new ManagementPackXmlWriter(outpath);

            ManagementPackBundle mpb = mpbReader.Read(inpath, mpStore);

            mpWrite.WriteManagementPack(mpb.ManagementPacks[0]);

            IDictionary<string,Stream> stream = mpb.GetStreams(mpb.ManagementPacks[0]);

            foreach(var f in stream.Keys)
            {
                var k = mpb.ManagementPacks[0].FindManagementPackElementByName(f);
                string filename = k.DisplayName;
                if(filename == null)
                {
                    filename = outpath + @"\" + k.Name + "." + stream + ".bin";

                }
                else
                {

                    if( filename.IndexOf(@"\") < 0 )
                    {

                        string dir = outpath + @"\" + filename.Substring(0, filename.IndexOf(@"\"));
                        Directory.CreateDirectory(dir);
                        

                    }
                    filename = outpath + @"\" + filename;
                    
                }
                var g = File.Create(filename);
                
            }

        }


    }
}





/*
 
  *$mpbReader = [Microsoft.EnterpriseManagement.Packaging.ManagementPackBundleFactory]::CreateBundleReader() 
 * $mpStore = new-Object Microsoft.EnterpriseManagement.Configuration.IO.ManagementPackFileStore($inDir)
 if ($mps -ne $null) 
{ 
    foreach ($file in $mps) 
    { 
        md ($outDir + "\"+ $file)  #ADDED      
        $mpWriter = new-object Microsoft.EnterpriseManagement.Configuration.IO.ManagementPackXmlWriter($outDir + "\"+ $file)    #ADDED    
        $mpb = $mpbReader.Read($file.FullName, $mpStore) 
        foreach($mp in $mpb.ManagementPacks) 
        { 
            #write the xml 
            $mpWriter.WriteManagementPack($mp) 
            $streams = $mpb.GetStreams($mp) 
            foreach($stream in $streams.Keys) 
            { 
                $mpElement = $mp.FindManagementPackElementByName($stream) 
                $fileName = $mpElement.FileName 
                if ($fileName -eq $null) 
                { 
                    $fileName = $outDir +'\' + ($mp.Name)+ '.' + $stream+ '.bin' 
                } 
                else 
                { 
                    If ($fileName.IndexOf('\') -gt 0) 
                    { 
                        #only on dir level supported 
                        $dir = $outDir + '\' + $fileName.SubString(0, $fileName.IndexOf('\')) 
                        if ([System.Io.Directory]::Exists($dir) -ne $true) 
                        { 
                            [System.Io.Directory]::CreateDirectory($dir) 
                        } 
                    } 
                    #$fileName = "${outdir}\${fileName}" 
                    $fileName = $outdir+"\"+$file+"\$filename" #ADDED 
                } 
                Write-Host "`t$fileName" 
                $fs = [system.io.file]::Create($fileName) 
                $streams[$stream].WriteTo($fs) 
                $fs.Close() 
            } 
        }  
 

 * 
 * 
 * 
 *  string destinationDirectory = @".\";
string bundleFileName = "RePackaging.Library";

ManagementPackBundle bundle = ManagementPackBundleFactory.CreateBundle();
ManagementPackBundleWriter bundleWriter = ManagementPackBundleFactory.CreateBundleWriter(destinationDirectory);

bundle.AddManagementPack(mp);
bundleWriter.Write(bundle, bundleFileName);
*/
